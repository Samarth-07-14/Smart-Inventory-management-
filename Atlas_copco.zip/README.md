# QR Code + PaddleOCR Scanner GUI
### Atlas Copco × Vishwakarma University | Raspberry Pi 5

---

## Features

| Feature | Detail |
|---|---|
| **Live Camera** | USB / CSI camera real-time QR detection |
| **Video File** | Scan MP4/AVI/MOV for embedded QR codes |
| **Photo Upload** | Scan single images (JPG/PNG/BMP) |
| **Unique QR IDs** | Each new QR data gets a permanent `QR-XXXX` UID |
| **PaddleOCR** | Toggle ON/OFF — extracts text from QR region |
| **Detection Log** | Scrollable table: UID, type, data, time, OCR |
| **QR Data Window** | Color-coded live text feed of all detections |
| **Right-click** | Copy data / OCR text, delete log rows |

---

## Installation on Raspberry Pi 5

```bash
chmod +x setup_and_run.sh
./setup_and_run.sh
```

### Manual install

```bash
# System
sudo apt-get install python3-tk libzbar0 python3-opencv

# Python
pip3 install opencv-python Pillow numpy pyzbar qrcode paddlepaddle paddleocr --break-system-packages

# Run
python3 qr_ocr_gui.py
```

---

## Camera Setup

- **USB webcam** — plug in and the app auto-selects `/dev/video0`
- **RPi Camera Module 3** — enable via `raspi-config → Interface → Camera`
  then use `libcamera` or a V4L2 bridge

---

## PaddleOCR Notes

- OCR initializes in background on startup (~10–30 s first run, downloads models)
- Toggle switch in the toolbar activates OCR per-frame on each detected QR region
- OCR text appears in both the QR Data window and the `OCR` column in the log table
- Status shown in bottom-right status bar

---

## Files

```
qr_ocr_gui.py       ← Main application
requirements.txt    ← Python dependencies
setup_and_run.sh    ← One-shot install + launch
README.md           ← This file
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `No module named 'pyzbar'` | `sudo apt install libzbar0 && pip3 install pyzbar` |
| Camera not found | Check `ls /dev/video*`, try index 1 or 2 in code |
| PaddleOCR slow | Normal on first run (model download); subsequent runs are fast |
| Black screen | Ensure `DISPLAY=:0` is set when running headless |
