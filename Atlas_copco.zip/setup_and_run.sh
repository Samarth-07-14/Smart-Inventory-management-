#!/bin/bash
# ============================================================
#  QR + OCR Scanner — Setup & Run Script
#  Raspberry Pi 5  (Bookworm / Ubuntu 24 ARM64)
# ============================================================

set -e

echo "════════════════════════════════════════════════"
echo "  Atlas Copco × Vishwakarma University"
echo "  QR Code + PaddleOCR Scanner — Setup"
echo "════════════════════════════════════════════════"

# ── System packages ──────────────────────────────────────────
echo "[1/4] Installing system dependencies..."
sudo apt-get update -qq
sudo apt-get install -y \
    python3-tk \
    python3-pip \
    python3-opencv \
    libzbar0 \
    libzbar-dev \
    libgl1-mesa-glx \
    libglib2.0-0 \
    libsm6 \
    libxrender1 \
    libxext6 \
    v4l-utils \
    libcamera-apps

# ── Python packages ───────────────────────────────────────────
echo "[2/4] Installing Python packages..."
pip3 install --upgrade pip --break-system-packages
pip3 install \
    opencv-python \
    Pillow \
    numpy \
    pyzbar \
    qrcode[pil] \
    --break-system-packages

# ── PaddleOCR (ARM64) ─────────────────────────────────────────
echo "[3/4] Installing PaddleOCR (this may take a few minutes)..."
pip3 install paddlepaddle --break-system-packages || \
    pip3 install paddlepaddle-cpu --break-system-packages || \
    echo "⚠  PaddleOCR install failed — OCR will be disabled at runtime."
pip3 install paddleocr --break-system-packages || \
    echo "⚠  paddleocr install failed."

# ── Launch ────────────────────────────────────────────────────
echo "[4/4] Launching QR Scanner GUI..."
DISPLAY=${DISPLAY:-:0}
export DISPLAY
python3 "$(dirname "$0")/qr_ocr_gui.py"
