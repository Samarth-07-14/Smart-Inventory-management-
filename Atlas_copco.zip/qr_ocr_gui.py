#!/usr/bin/env python3
"""
Atlas Copco x Vishwakarma University
QR Code Detection + PaddleOCR Integration GUI
Optimized for Raspberry Pi 5
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import cv2
import numpy as np
from PIL import Image, ImageTk
import threading
import time
import queue
import os
import sys
from datetime import datetime
import json

# ── QR / Barcode ─────────────────────────────────────────────
try:
    from pyzbar import pyzbar
    PYZBAR_OK = True
except ImportError:
    PYZBAR_OK = False

try:
    import qrcode
    QRCODE_OK = True
except ImportError:
    QRCODE_OK = False

# ── PaddleOCR ────────────────────────────────────────────────
try:
    from paddleocr import PaddleOCR
    PADDLE_AVAILABLE = True
except ImportError:
    PADDLE_AVAILABLE = False

# ── OpenCV built-in QR detector (fallback) ───────────────────
CV_QR_DETECTOR = cv2.QRCodeDetector()

# ─────────────────────────────────────────────────────────────
#  COLOUR PALETTE
# ─────────────────────────────────────────────────────────────
BG_DARK       = "#0D1117"
BG_CARD       = "#161B22"
BG_CARD2      = "#1C2128"
ACCENT_BLUE   = "#1D6FA4"   # Atlas Copco blue
ACCENT_GOLD   = "#F5A623"   # VU gold
TEXT_PRIMARY  = "#E6EDF3"
TEXT_SECONDARY= "#8B949E"
TEXT_GREEN    = "#3FB950"
TEXT_RED      = "#F85149"
BORDER_COLOR  = "#30363D"
HIGHLIGHT     = "#388BFD"

FONT_TITLE  = ("Helvetica Neue", 13, "bold")
FONT_BODY   = ("Helvetica Neue", 10)
FONT_MONO   = ("Courier New",    10)
FONT_SMALL  = ("Helvetica Neue",  9)
FONT_LARGE  = ("Helvetica Neue", 18, "bold")

# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────
def make_placeholder_logo(text: str, color: str, size=(120, 40)) -> ImageTk.PhotoImage:
    img = Image.new("RGBA", size, (0, 0, 0, 0))
    from PIL import ImageDraw, ImageFont
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 14)
    except Exception:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0, 0), text, font=font)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    x = (size[0] - w) // 2
    y = (size[1] - h) // 2
    hex_col = color.lstrip("#")
    r, g, b = int(hex_col[0:2], 16), int(hex_col[2:4], 16), int(hex_col[4:6], 16)
    draw.rounded_rectangle([2, 2, size[0]-3, size[1]-3], radius=6,
                           outline=(r, g, b, 255), width=2)
    draw.text((x, y), text, fill=(r, g, b, 255), font=font)
    return ImageTk.PhotoImage(img)


# ─────────────────────────────────────────────────────────────
#  MAIN APPLICATION
# ─────────────────────────────────────────────────────────────
class QRScannerApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("QR & OCR Scanner — Atlas Copco × Vishwakarma University")
        self.configure(bg=BG_DARK)
        self.state("zoomed") if sys.platform == "win32" else self.attributes("-zoomed", True)
        self.minsize(1100, 700)

        # ── State ────────────────────────────────────────────
        self.mode           = tk.StringVar(value="live")   # live | video | photo
        self.ocr_enabled    = tk.BooleanVar(value=False)
        self.running        = False
        self.cap            = None
        self.frame_queue    = queue.Queue(maxsize=2)
        self.result_queue   = queue.Queue(maxsize=20)

        self.qr_registry    : dict[str, dict] = {}   # data → {uid, first_seen, count}
        self.uid_counter    = 0
        self.detected_log   : list[dict] = []

        self.ocr_engine     = None
        self.ocr_ready      = False

        # ── Build UI ─────────────────────────────────────────
        self._build_header()
        self._build_main()
        self._build_status_bar()

        # ── Boot OCR in background ───────────────────────────
        if PADDLE_AVAILABLE:
            threading.Thread(target=self._init_ocr, daemon=True).start()

        # ── Poll result queue ─────────────────────────────────
        self.after(50, self._poll_results)

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ═══════════════════════════════════════════════════════════
    #  HEADER
    # ═══════════════════════════════════════════════════════════
    def _build_header(self):
        hdr = tk.Frame(self, bg=BG_CARD, height=64)
        hdr.pack(fill="x", side="top")
        hdr.pack_propagate(False)

        # left logo placeholder
        lf = tk.Frame(hdr, bg=BG_CARD)
        lf.pack(side="left", padx=16, pady=10)
        self._ac_logo = make_placeholder_logo("ATLAS COPCO", ACCENT_BLUE, (140, 44))
        tk.Label(lf, image=self._ac_logo, bg=BG_CARD).pack()

        # centre title
        cf = tk.Frame(hdr, bg=BG_CARD)
        cf.pack(side="left", expand=True)
        tk.Label(cf, text="QR CODE & OCR SCANNER",
                 font=("Helvetica Neue", 15, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_CARD).pack(side="top")
        tk.Label(cf, text="Industrial Vision System  |  Raspberry Pi 5",
                 font=FONT_SMALL, fg=TEXT_SECONDARY, bg=BG_CARD).pack()

        # right logo placeholder
        rf = tk.Frame(hdr, bg=BG_CARD)
        rf.pack(side="right", padx=16, pady=10)
        self._vu_logo = make_placeholder_logo("VISHWAKARMA UNIV", ACCENT_GOLD, (155, 44))
        tk.Label(rf, image=self._vu_logo, bg=BG_CARD).pack()

        # separator
        tk.Frame(self, bg=BORDER_COLOR, height=1).pack(fill="x")

    # ═══════════════════════════════════════════════════════════
    #  MAIN AREA
    # ═══════════════════════════════════════════════════════════
    def _build_main(self):
        main = tk.Frame(self, bg=BG_DARK)
        main.pack(fill="both", expand=True, padx=10, pady=8)
        main.columnconfigure(0, weight=3)
        main.columnconfigure(1, weight=2)
        main.rowconfigure(0, weight=1)

        self._build_left_panel(main)
        self._build_right_panel(main)

    # ─── LEFT PANEL ──────────────────────────────────────────
    def _build_left_panel(self, parent):
        lf = tk.Frame(parent, bg=BG_DARK)
        lf.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        lf.rowconfigure(1, weight=1)
        lf.columnconfigure(0, weight=1)

        # Control bar
        ctrl = tk.Frame(lf, bg=BG_CARD, pady=8, padx=10)
        ctrl.grid(row=0, column=0, sticky="ew", pady=(0, 6))

        # Mode buttons
        tk.Label(ctrl, text="INPUT MODE:", font=FONT_SMALL,
                 fg=TEXT_SECONDARY, bg=BG_CARD).pack(side="left", padx=(0, 8))

        self._btn_live  = self._mode_btn(ctrl, "📷  LIVE",  "live")
        self._btn_video = self._mode_btn(ctrl, "🎬  VIDEO", "video")
        self._btn_photo = self._mode_btn(ctrl, "🖼  PHOTO", "photo")

        tk.Frame(ctrl, bg=BORDER_COLOR, width=1).pack(side="left", fill="y", padx=10)

        # OCR toggle
        tk.Label(ctrl, text="PADDLEOCR:", font=FONT_SMALL,
                 fg=TEXT_SECONDARY, bg=BG_CARD).pack(side="left", padx=(0, 4))
        self._ocr_switch = tk.Checkbutton(
            ctrl, variable=self.ocr_enabled,
            text="", onvalue=True, offvalue=False,
            bg=BG_CARD, activebackground=BG_CARD,
            selectcolor=ACCENT_BLUE, fg=TEXT_GREEN,
            command=self._on_ocr_toggle
        )
        self._ocr_switch.pack(side="left")
        self._ocr_label = tk.Label(ctrl, text="OFF", font=FONT_SMALL,
                                   fg=TEXT_RED, bg=BG_CARD)
        self._ocr_label.pack(side="left", padx=(0, 10))

        # Upload / Start buttons
        self._btn_upload = tk.Button(
            ctrl, text="Upload", font=FONT_SMALL, bg=ACCENT_BLUE, fg="white",
            relief="flat", padx=10, pady=4, cursor="hand2",
            command=self._upload_file
        )
        self._btn_upload.pack(side="left", padx=4)
        self._btn_upload.pack_forget()  # hidden until mode != live

        self._btn_start = tk.Button(
            ctrl, text="▶  Start Camera", font=FONT_SMALL,
            bg=TEXT_GREEN, fg=BG_DARK, relief="flat",
            padx=10, pady=4, cursor="hand2",
            command=self._toggle_camera
        )
        self._btn_start.pack(side="left", padx=4)

        self._btn_clear = tk.Button(
            ctrl, text="🗑  Clear Log", font=FONT_SMALL,
            bg=BG_CARD2, fg=TEXT_SECONDARY, relief="flat",
            padx=10, pady=4, cursor="hand2",
            command=self._clear_log
        )
        self._btn_clear.pack(side="right", padx=4)

        # Camera / image canvas
        cam_frame = tk.Frame(lf, bg=BG_CARD, bd=0)
        cam_frame.grid(row=1, column=0, sticky="nsew")

        self.canvas = tk.Canvas(cam_frame, bg="#000000",
                                highlightthickness=1,
                                highlightbackground=BORDER_COLOR)
        self.canvas.pack(fill="both", expand=True, padx=2, pady=2)
        self._show_idle_canvas()

    def _mode_btn(self, parent, label, mode):
        is_active = (self.mode.get() == mode)
        btn = tk.Button(
            parent, text=label, font=FONT_SMALL,
            bg=ACCENT_BLUE if is_active else BG_CARD2,
            fg=TEXT_PRIMARY, relief="flat",
            padx=8, pady=4, cursor="hand2",
            command=lambda m=mode: self._set_mode(m)
        )
        btn.pack(side="left", padx=2)
        return btn

    # ─── RIGHT PANEL ─────────────────────────────────────────
    def _build_right_panel(self, parent):
        rf = tk.Frame(parent, bg=BG_DARK)
        rf.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        rf.rowconfigure(0, weight=2)
        rf.rowconfigure(1, weight=3)
        rf.columnconfigure(0, weight=1)

        # ── QR Data display ──────────────────────────────────
        qr_card = self._card(rf, "📦  DETECTED QR DATA", row=0)
        qr_card.rowconfigure(0, weight=1)
        qr_card.columnconfigure(0, weight=1)

        self.qr_text = tk.Text(
            qr_card, bg=BG_DARK, fg=TEXT_GREEN,
            font=FONT_MONO, relief="flat", wrap="word",
            state="disabled", padx=8, pady=6,
            insertbackground=TEXT_GREEN,
            selectbackground=ACCENT_BLUE
        )
        qs = ttk.Scrollbar(qr_card, command=self.qr_text.yview)
        self.qr_text.configure(yscrollcommand=qs.set)
        self.qr_text.grid(row=0, column=0, sticky="nsew")
        qs.grid(row=0, column=1, sticky="ns")

        # ── Log table ────────────────────────────────────────
        log_card = self._card(rf, "📋  DETECTION LOG", row=1)
        log_card.rowconfigure(0, weight=1)
        log_card.columnconfigure(0, weight=1)

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Dark.Treeview",
                        background=BG_DARK, foreground=TEXT_PRIMARY,
                        fieldbackground=BG_DARK, rowheight=22,
                        font=FONT_SMALL)
        style.configure("Dark.Treeview.Heading",
                        background=BG_CARD2, foreground=ACCENT_GOLD,
                        font=("Helvetica Neue", 9, "bold"), relief="flat")
        style.map("Dark.Treeview",
                  background=[("selected", ACCENT_BLUE)],
                  foreground=[("selected", "white")])

        cols = ("uid", "type", "data", "time", "ocr")
        self.tree = ttk.Treeview(log_card, columns=cols,
                                 show="headings", style="Dark.Treeview")
        self.tree.heading("uid",  text="#UID")
        self.tree.heading("type", text="Type")
        self.tree.heading("data", text="QR Data")
        self.tree.heading("time", text="Time")
        self.tree.heading("ocr",  text="OCR Text")
        self.tree.column("uid",  width=55,  stretch=False)
        self.tree.column("type", width=65,  stretch=False)
        self.tree.column("data", width=160, stretch=True)
        self.tree.column("time", width=75,  stretch=False)
        self.tree.column("ocr",  width=130, stretch=True)

        vsb = ttk.Scrollbar(log_card, orient="vertical",   command=self.tree.yview)
        hsb = ttk.Scrollbar(log_card, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        # right-click context
        self.tree.bind("<Button-3>", self._tree_context_menu)

    def _card(self, parent, title: str, row: int) -> tk.Frame:
        wrapper = tk.Frame(parent, bg=BG_DARK)
        wrapper.grid(row=row, column=0, sticky="nsew",
                     pady=(0, 6) if row == 0 else 0)
        wrapper.rowconfigure(1, weight=1)
        wrapper.columnconfigure(0, weight=1)

        hdr = tk.Frame(wrapper, bg=BG_CARD2, pady=5, padx=10)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text=title, font=FONT_TITLE,
                 fg=ACCENT_GOLD, bg=BG_CARD2).pack(side="left")

        body = tk.Frame(wrapper, bg=BG_DARK,
                        highlightthickness=1,
                        highlightbackground=BORDER_COLOR)
        body.grid(row=1, column=0, sticky="nsew")
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)
        return body

    # ═══════════════════════════════════════════════════════════
    #  STATUS BAR
    # ═══════════════════════════════════════════════════════════
    def _build_status_bar(self):
        tk.Frame(self, bg=BORDER_COLOR, height=1).pack(fill="x")
        sb = tk.Frame(self, bg=BG_CARD, height=26)
        sb.pack(fill="x", side="bottom")
        sb.pack_propagate(False)

        self._lbl_status = tk.Label(sb, text="● IDLE", font=FONT_SMALL,
                                    fg=TEXT_SECONDARY, bg=BG_CARD)
        self._lbl_status.pack(side="left", padx=12)

        self._lbl_fps = tk.Label(sb, text="FPS: —", font=FONT_SMALL,
                                 fg=TEXT_SECONDARY, bg=BG_CARD)
        self._lbl_fps.pack(side="left", padx=12)

        self._lbl_count = tk.Label(sb, text="Detected: 0", font=FONT_SMALL,
                                   fg=TEXT_SECONDARY, bg=BG_CARD)
        self._lbl_count.pack(side="left", padx=12)

        self._lbl_ocr_status = tk.Label(
            sb,
            text="PaddleOCR: Loading…" if PADDLE_AVAILABLE else "PaddleOCR: Not installed",
            font=FONT_SMALL,
            fg=ACCENT_GOLD if PADDLE_AVAILABLE else TEXT_RED,
            bg=BG_CARD
        )
        self._lbl_ocr_status.pack(side="right", padx=12)

        ts = tk.Label(sb, text=datetime.now().strftime("%Y-%m-%d"),
                      font=FONT_SMALL, fg=TEXT_SECONDARY, bg=BG_CARD)
        ts.pack(side="right", padx=12)
        self._update_clock(ts)

    def _update_clock(self, lbl):
        lbl.config(text=datetime.now().strftime("%H:%M:%S  %Y-%m-%d"))
        self.after(1000, lambda: self._update_clock(lbl))

    # ═══════════════════════════════════════════════════════════
    #  IDLE CANVAS PLACEHOLDER
    # ═══════════════════════════════════════════════════════════
    def _show_idle_canvas(self):
        self.canvas.delete("all")
        w = self.canvas.winfo_width()  or 640
        h = self.canvas.winfo_height() or 480
        cx, cy = w // 2, h // 2
        self.canvas.create_rectangle(0, 0, w, h, fill="#000000", outline="")
        self.canvas.create_text(cx, cy - 20, text="[ No Feed ]",
                                fill=TEXT_SECONDARY, font=("Courier New", 16))
        self.canvas.create_text(cx, cy + 16,
                                text="Select a mode and press ▶  Start Camera",
                                fill=TEXT_SECONDARY, font=FONT_SMALL)

    # ═══════════════════════════════════════════════════════════
    #  OCR INIT
    # ═══════════════════════════════════════════════════════════
    def _init_ocr(self):
        try:
            self._lbl_ocr_status.config(text="PaddleOCR: Initializing…", fg=ACCENT_GOLD)
            self.ocr_engine = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
            self.ocr_ready = True
            self._lbl_ocr_status.config(text="PaddleOCR: Ready ✓", fg=TEXT_GREEN)
        except Exception as e:
            self._lbl_ocr_status.config(text=f"PaddleOCR: Error — {e}", fg=TEXT_RED)

    # ═══════════════════════════════════════════════════════════
    #  MODE & CONTROLS
    # ═══════════════════════════════════════════════════════════
    def _set_mode(self, mode: str):
        self._stop_stream()
        self.mode.set(mode)
        for btn, m in [(self._btn_live, "live"),
                       (self._btn_video, "video"),
                       (self._btn_photo, "photo")]:
            btn.config(bg=ACCENT_BLUE if mode == m else BG_CARD2)

        if mode == "live":
            self._btn_upload.pack_forget()
            self._btn_start.config(text="▶  Start Camera", state="normal")
        else:
            self._btn_upload.pack(side="left", padx=4, before=self._btn_start)
            self._btn_start.config(
                text=("▶  Start Video" if mode == "video" else "▶  Scan Photo"),
                state="disabled"
            )
        self._show_idle_canvas()
        self._set_status("IDLE", TEXT_SECONDARY)

    def _on_ocr_toggle(self):
        if self.ocr_enabled.get():
            if not PADDLE_AVAILABLE:
                messagebox.showwarning("PaddleOCR",
                    "PaddleOCR is not installed.\nRun: pip install paddleocr paddlepaddle")
                self.ocr_enabled.set(False)
                return
            if not self.ocr_ready:
                messagebox.showinfo("PaddleOCR", "OCR engine is still initializing. Please wait.")
                self.ocr_enabled.set(False)
                return
            self._ocr_label.config(text="ON", fg=TEXT_GREEN)
        else:
            self._ocr_label.config(text="OFF", fg=TEXT_RED)

    def _upload_file(self):
        mode = self.mode.get()
        if mode == "video":
            path = filedialog.askopenfilename(
                title="Select Video File",
                filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv *.webm"), ("All", "*.*")]
            )
            if path:
                self._btn_start.config(state="normal")
                self._video_path = path
                self._set_status(f"Video: {os.path.basename(path)}", ACCENT_GOLD)
        else:
            path = filedialog.askopenfilename(
                title="Select Image File",
                filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp *.tiff"), ("All", "*.*")]
            )
            if path:
                self._btn_start.config(state="normal")
                self._photo_path = path
                self._set_status(f"Photo: {os.path.basename(path)}", ACCENT_GOLD)

    def _toggle_camera(self):
        if self.running:
            self._stop_stream()
        else:
            self._start_stream()

    def _start_stream(self):
        mode = self.mode.get()
        self.running = True
        self._btn_start.config(text="⏹  Stop", bg=TEXT_RED, fg="white")
        self._set_status("RUNNING", TEXT_GREEN)

        if mode == "live":
            t = threading.Thread(target=self._live_loop, daemon=True)
        elif mode == "video":
            t = threading.Thread(target=self._video_loop,
                                 args=(getattr(self, "_video_path", ""),),
                                 daemon=True)
        else:
            self._process_photo(getattr(self, "_photo_path", ""))
            self._stop_stream()
            return
        t.start()

    def _stop_stream(self):
        self.running = False
        if self.cap:
            self.cap.release()
            self.cap = None
        self._btn_start.config(text="▶  Start Camera", bg=TEXT_GREEN, fg=BG_DARK)
        self._set_status("STOPPED", TEXT_SECONDARY)

    # ═══════════════════════════════════════════════════════════
    #  FRAME LOOPS
    # ═══════════════════════════════════════════════════════════
    def _live_loop(self):
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.result_queue.put({"type": "error", "msg": "Cannot open camera."})
            self.running = False
            return
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,  720)
        self._stream_loop()

    def _video_loop(self, path: str):
        if not path or not os.path.exists(path):
            self.result_queue.put({"type": "error", "msg": "Video file not found."})
            self.running = False
            return
        self.cap = cv2.VideoCapture(path)
        self._stream_loop()

    def _stream_loop(self):
        fps_t = time.time()
        frame_count = 0
        while self.running and self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if not ret:
                # video ended — loop back
                if self.mode.get() == "video":
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                break

            frame_count += 1
            elapsed = time.time() - fps_t
            if elapsed >= 1.0:
                fps = frame_count / elapsed
                self.result_queue.put({"type": "fps", "value": fps})
                frame_count = 0
                fps_t = time.time()

            annotated, detections = self._detect_qr(frame)
            for det in detections:
                self._register_detection(det, frame)

            rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
            self.result_queue.put({"type": "frame", "frame": rgb})
            time.sleep(0.01)

        self.running = False

    def _process_photo(self, path: str):
        if not path or not os.path.exists(path):
            messagebox.showerror("Error", "Image file not found.")
            return
        frame = cv2.imread(path)
        if frame is None:
            messagebox.showerror("Error", "Cannot read image.")
            return
        annotated, detections = self._detect_qr(frame)
        for det in detections:
            self._register_detection(det, frame)
        rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
        self.result_queue.put({"type": "frame", "frame": rgb})

    # ═══════════════════════════════════════════════════════════
    #  QR DETECTION
    # ═══════════════════════════════════════════════════════════
    def _detect_qr(self, frame: np.ndarray):
        annotated = frame.copy()
        detections = []

        # pyzbar (preferred — supports QR, Code128, EAN, etc.)
        if PYZBAR_OK:
            barcodes = pyzbar.decode(frame)
            for bc in barcodes:
                data = bc.data.decode("utf-8", errors="replace")
                pts  = np.array(bc.polygon, np.int32).reshape((-1, 1, 2))
                cv2.polylines(annotated, [pts], True, (0, 255, 80), 2)
                x, y, w, h = bc.rect
                cv2.rectangle(annotated, (x, y), (x+w, y+h), (0, 200, 255), 1)
                cv2.putText(annotated, data[:30], (x, y - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 80), 1)
                roi = frame[max(0,y-5):y+h+5, max(0,x-5):x+w+5]
                detections.append({"data": data, "type": bc.type, "roi": roi,
                                   "bbox": (x, y, w, h)})
        else:
            # OpenCV fallback — QR only
            data, pts, _ = CV_QR_DETECTOR.detectAndDecode(frame)
            if data and pts is not None:
                pts = pts.astype(np.int32).reshape((-1, 1, 2))
                cv2.polylines(annotated, [pts], True, (0, 255, 80), 2)
                x, y, w, h = cv2.boundingRect(pts)
                cv2.putText(annotated, data[:30], (x, y - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 80), 1)
                roi = frame[max(0,y-5):y+h+5, max(0,x-5):x+w+5]
                detections.append({"data": data, "type": "QRCODE", "roi": roi,
                                   "bbox": (x, y, w, h)})

        return annotated, detections

    # ═══════════════════════════════════════════════════════════
    #  REGISTER & UNIQUE ID
    # ═══════════════════════════════════════════════════════════
    def _register_detection(self, det: dict, frame: np.ndarray):
        data = det["data"]
        now  = datetime.now().strftime("%H:%M:%S")

        if data not in self.qr_registry:
            self.uid_counter += 1
            uid = f"QR-{self.uid_counter:04d}"
            self.qr_registry[data] = {"uid": uid, "first_seen": now, "count": 1}
        else:
            self.qr_registry[data]["count"] += 1
            uid = self.qr_registry[data]["uid"]

        # OCR on ROI
        ocr_text = ""
        if self.ocr_enabled.get() and self.ocr_ready and self.ocr_engine:
            try:
                roi = det.get("roi")
                if roi is not None and roi.size > 0:
                    result = self.ocr_engine.ocr(roi, cls=True)
                    if result and result[0]:
                        ocr_text = " | ".join(
                            line[1][0] for line in result[0] if line and line[1]
                        )
            except Exception:
                ocr_text = "OCR error"

        entry = {
            "uid":      uid,
            "type":     det["type"],
            "data":     data,
            "time":     now,
            "ocr":      ocr_text,
            "count":    self.qr_registry[data]["count"],
        }
        self.result_queue.put({"type": "detection", "entry": entry})

    # ═══════════════════════════════════════════════════════════
    #  RESULT QUEUE POLLING (main thread)
    # ═══════════════════════════════════════════════════════════
    def _poll_results(self):
        try:
            while True:
                msg = self.result_queue.get_nowait()
                mt  = msg["type"]

                if mt == "frame":
                    self._render_frame(msg["frame"])

                elif mt == "detection":
                    self._update_detection_ui(msg["entry"])

                elif mt == "fps":
                    self._lbl_fps.config(text=f"FPS: {msg['value']:.1f}")

                elif mt == "error":
                    messagebox.showerror("Error", msg["msg"])
                    self._stop_stream()

        except queue.Empty:
            pass
        self.after(30, self._poll_results)

    # ─── Render frame onto canvas ─────────────────────────────
    def _render_frame(self, rgb_array: np.ndarray):
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw < 10 or ch < 10:
            return
        ih, iw = rgb_array.shape[:2]
        scale = min(cw / iw, ch / ih)
        nw, nh = int(iw * scale), int(ih * scale)
        img = Image.fromarray(rgb_array).resize((nw, nh), Image.BILINEAR)
        self._tk_img = ImageTk.PhotoImage(img)
        self.canvas.delete("all")
        self.canvas.create_image(cw // 2, ch // 2, anchor="center",
                                 image=self._tk_img)

    # ─── Update QR data box + table ──────────────────────────
    def _update_detection_ui(self, entry: dict):
        # Only add new unique QRs to table; update count for duplicates
        uid  = entry["uid"]
        data = entry["data"]

        # check if already in tree
        existing = None
        for iid in self.tree.get_children():
            if self.tree.item(iid, "values")[0] == uid:
                existing = iid
                break

        tag = "new" if existing is None else "dup"
        row_vals = (uid, entry["type"], data[:60], entry["time"], entry["ocr"][:40])

        if existing is None:
            iid = self.tree.insert("", 0, values=row_vals, tags=(tag,))
            self.tree.tag_configure("new", foreground=TEXT_GREEN)
            self.tree.tag_configure("dup", foreground=TEXT_SECONDARY)
            self.detected_log.append(entry)
            # Update big text display
            self._append_qr_text(entry)
        else:
            self.tree.item(existing, values=row_vals)

        self._lbl_count.config(text=f"Detected: {len(self.qr_registry)}")

    def _append_qr_text(self, entry: dict):
        self.qr_text.config(state="normal")
        ts = f"[{entry['time']}] "
        uid_str  = f"{entry['uid']}  "
        type_str = f"({entry['type']})\n"
        data_str = f"  DATA : {entry['data']}\n"
        ocr_str  = f"  OCR  : {entry['ocr']}\n" if entry["ocr"] else ""
        sep      = "─" * 44 + "\n"

        self.qr_text.insert("end", ts,       "ts")
        self.qr_text.insert("end", uid_str,  "uid")
        self.qr_text.insert("end", type_str, "typ")
        self.qr_text.insert("end", data_str, "dat")
        if ocr_str:
            self.qr_text.insert("end", ocr_str, "ocr")
        self.qr_text.insert("end", sep, "sep")
        self.qr_text.tag_config("ts",  foreground=TEXT_SECONDARY)
        self.qr_text.tag_config("uid", foreground=ACCENT_GOLD)
        self.qr_text.tag_config("typ", foreground=TEXT_SECONDARY)
        self.qr_text.tag_config("dat", foreground=TEXT_GREEN)
        self.qr_text.tag_config("ocr", foreground=HIGHLIGHT)
        self.qr_text.tag_config("sep", foreground=BORDER_COLOR)
        self.qr_text.see("end")
        self.qr_text.config(state="disabled")

    # ═══════════════════════════════════════════════════════════
    #  MISC UI
    # ═══════════════════════════════════════════════════════════
    def _clear_log(self):
        if messagebox.askyesno("Clear", "Clear all detected QR logs?"):
            self.qr_registry.clear()
            self.detected_log.clear()
            self.uid_counter = 0
            self.tree.delete(*self.tree.get_children())
            self.qr_text.config(state="normal")
            self.qr_text.delete("1.0", "end")
            self.qr_text.config(state="disabled")
            self._lbl_count.config(text="Detected: 0")

    def _set_status(self, text: str, color: str):
        dot = "●"
        self._lbl_status.config(text=f"{dot} {text}", fg=color)

    def _tree_context_menu(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        self.tree.selection_set(iid)
        vals = self.tree.item(iid, "values")
        menu = tk.Menu(self, tearoff=False, bg=BG_CARD2, fg=TEXT_PRIMARY,
                       activebackground=ACCENT_BLUE)
        menu.add_command(label="Copy Data",
                         command=lambda: self._copy_to_clipboard(vals[2]))
        menu.add_command(label="Copy OCR Text",
                         command=lambda: self._copy_to_clipboard(vals[4]))
        menu.add_separator()
        menu.add_command(label="Delete Row",
                         command=lambda: self.tree.delete(iid))
        menu.post(event.x_root, event.y_root)

    def _copy_to_clipboard(self, text: str):
        self.clipboard_clear()
        self.clipboard_append(text)

    def _on_close(self):
        self.running = False
        if self.cap:
            self.cap.release()
        self.destroy()


# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = QRScannerApp()
    app.mainloop()
